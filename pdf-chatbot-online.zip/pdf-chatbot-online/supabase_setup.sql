-- ==============================================================
-- รันสคริปต์นี้ใน Supabase: เมนู "SQL Editor" -> New query -> วางแล้วกด Run
-- ทำครั้งเดียวตอนตั้งค่าโปรเจกต์ครั้งแรก
-- ==============================================================

-- เปิดใช้งานส่วนขยาย pgvector (สำหรับเก็บ/ค้นหาเวกเตอร์)
create extension if not exists vector;

-- ตารางเก็บชิ้นเนื้อหา (chunk) พร้อมเวกเตอร์ ใช้สำหรับค้นหา
create table if not exists documents (
    id bigserial primary key,
    content text not null,
    metadata jsonb not null,       -- เก็บ {"source": "ชื่อไฟล์.pdf", "page": 12}
    embedding vector(768)          -- 768 มิติ ตามโมเดล text-embedding-004 ของ Google
);

-- ตารางเก็บรายชื่อไฟล์ PDF ที่อยู่ในคลัง (สำหรับหน้า "จัดการคลังไฟล์")
create table if not exists pdf_files (
    id bigserial primary key,
    filename text unique not null,
    storage_path text not null,
    uploaded_at timestamptz default now(),
    page_count int,
    chunk_count int
);

-- ฟังก์ชันค้นหาชิ้นเนื้อหาที่ใกล้เคียงกับคำถามมากที่สุด (ใช้ cosine similarity)
create or replace function match_documents (
  query_embedding vector(768),
  match_count int default 5
)
returns table (
  id bigint,
  content text,
  metadata jsonb,
  similarity float
)
language sql stable
as $$
  select
    documents.id,
    documents.content,
    documents.metadata,
    1 - (documents.embedding <=> query_embedding) as similarity
  from documents
  order by documents.embedding <=> query_embedding
  limit match_count;
$$;

-- ดัชนีช่วยให้ค้นหาเร็วขึ้นเมื่อข้อมูลเยอะ (ivfflat index)
create index if not exists documents_embedding_idx
  on documents using ivfflat (embedding vector_cosine_ops)
  with (lists = 100);
